package com.kumu.czdan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.Toast;

public class SplashActivity extends AppCompatActivity {

    ImageView logo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        logo = findViewById(R.id.logo);
        Thread logoAnimation = new Thread() {
            @Override
            public void run() {
                super.run();
                Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.logo_animation);
                logo.startAnimation(animation);
            }
        };
        logoAnimation.start();
        Thread redirect = new Thread() {
            @Override
            public void run() {
                super.run();
                try {
                    //TODO Shared Preferences Olayına Bak sorun çözüldü !
                    sleep(1500);
                    Boolean isFirstRun = getSharedPreferences("PREFERENCE", MODE_PRIVATE)
                            .getBoolean("isFirstRun", true);
                    if (!isFirstRun) {
                        Intent intent = new Intent(SplashActivity.this, Main2Activity.class);
                        startActivity(intent);
                        finish();
                    }else{
                        Intent intent = new Intent(SplashActivity.this, UserInfoActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        finish();
                    }
                    getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit().putBoolean("isFirstRun", false).apply();

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };
        redirect.start();
    }
}